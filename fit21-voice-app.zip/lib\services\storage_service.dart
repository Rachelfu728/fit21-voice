import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/reminder_item.dart';

class StorageService {
  static const String _keyReminders = 'user_reminders_list_v1';
  static const String _keyApiKey = 'gemini_api_key';
  static const String _keyTtsEnabled = 'tts_enabled';
  static const String _keyTtsRate = 'tts_speech_rate';
  static const String _keyLocale = 'speech_locale';

  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  SharedPreferences get prefs {
    if (_prefs == null) {
      throw StateError('StorageService 尚未初始化，請先呼叫 init()');
    }
    return _prefs!;
  }

  // --- 提醒事項 CRUD ---

  List<ReminderItem> getReminders() {
    final raw = prefs.getStringList(_keyReminders) ?? [];
    final list = <ReminderItem>[];
    for (final itemStr in raw) {
      try {
        final map = jsonDecode(itemStr) as Map<String, dynamic>;
        list.add(ReminderItem.fromJson(map));
      } catch (e) {
        print('解析提醒項目失敗: $e');
      }
    }
    // 依提醒時間由近到遠排序
    list.sort((a, b) => a.reminderTime.compareTo(b.reminderTime));
    return list;
  }

  Future<void> saveReminder(ReminderItem item) async {
    final list = getReminders();
    final index = list.indexWhere((element) => element.id == item.id);
    if (index >= 0) {
      list[index] = item;
    } else {
      list.add(item);
    }
    await _persistReminders(list);
  }

  Future<void> updateReminder(ReminderItem item) async {
    await saveReminder(item);
  }

  Future<void> deleteReminder(String id) async {
    final list = getReminders();
    list.removeWhere((element) => element.id == id);
    await _persistReminders(list);
  }

  Future<ReminderItem?> toggleComplete(String id) async {
    final list = getReminders();
    final index = list.indexWhere((element) => element.id == id);
    if (index >= 0) {
      final updated = list[index].copyWith(isCompleted: !list[index].isCompleted);
      list[index] = updated;
      await _persistReminders(list);
      return updated;
    }
    return null;
  }

  Future<void> clearCompleted() async {
    final list = getReminders();
    list.removeWhere((element) => element.isCompleted);
    await _persistReminders(list);
  }

  Future<void> _persistReminders(List<ReminderItem> list) async {
    final strList = list.map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_keyReminders, strList);
  }

  // --- 設定管理 ---

  String getApiKey() {
    return prefs.getString(_keyApiKey) ?? '';
  }

  Future<void> setApiKey(String key) async {
    await prefs.setString(_keyApiKey, key.trim());
  }

  bool isTtsEnabled() {
    return prefs.getBool(_keyTtsEnabled) ?? true;
  }

  Future<void> setTtsEnabled(bool enabled) async {
    await prefs.setBool(_keyTtsEnabled, enabled);
  }

  double getTtsRate() {
    return prefs.getDouble(_keyTtsRate) ?? 0.5;
  }

  Future<void> setTtsRate(double rate) async {
    await prefs.setDouble(_keyTtsRate, rate);
  }

  String getSpeechLocale() {
    return prefs.getString(_keyLocale) ?? 'zh_TW';
  }

  Future<void> setSpeechLocale(String locale) async {
    await prefs.setString(_keyLocale, locale);
  }
}
