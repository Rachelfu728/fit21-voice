# 🎙️ AI 語音智能記事與提醒助理 (Voice Reminder Assistant)

這是一款專為智慧型手機（iOS / Android）打造的 **AI 語音提醒助理 App**，採用 **Flutter** 跨平台技術開發。

您可以直接**對著手機口說**要記住的事項（例如：「明天下午3點提醒我去郵局寄信」），App 會透過 **Google Gemini AI** 自動分析出事項與確切時間，設定系統定時鬧鐘／通知，並用語音溫柔回覆確認！

---

## 🌟 核心特色

1. **🎙️ 一鍵口說錄入 (Speech-to-Text)**
   - 點擊底部麥克風按鈕即可開始口說，支援繁體中文（台灣）與日常口語辨識。
   - 動態水波音波回饋動畫，即時看到說出的語句。

2. **🤖 Google Gemini 智能語意與時間解析**
   - 自動將口語自然語言轉換為結構化資料（標題、精確日期時間、分類）。
   - 支援相對時間（如「半小時後」、「10分鐘後」、「明天上午十點」、「大後天晚上」）。
   - **內建離線備用語意引擎**：若尚未設定 API Key 或無網路連線，系統會自動切換為本地離線規則解析，確保 100% 隨時可用！

3. **🔊 AI 語音即時回覆 (Text-to-Speech)**
   - 語音辨識完成後，助理會主動開口朗讀確認（例：「好的！已為您設定明天下午 3:00 去郵局寄信的提醒」），口說後完全不用低頭盯著螢幕。

4. **⏰ 系統級背景定時推播通知 (Exact Alarms & Scheduled Notifications)**
   - 整合 Android Exact Alarm 與 iOS UserNotification。
   - 即使 App 關閉或手機鎖定，時間一到也會準時跳出通知並響鈴提醒。

5. **📋 便捷卡片式管理**
   - 支援「全部 / 今日 / 即將到來 / 已完成」分類切換。
   - 一鍵勾選完成、延後 15 分鐘 (Snooze)、滑動手勢快速刪除。
   - 逾期項目自動紅字警示標記。

---

## 📱 專案目錄結構

```text
voice_reminder_assistant/
├── android/                  # Android 原生專案設定 (權限、廣播接收器)
├── ios/                      # iOS 原生專案設定 (麥克風與語音辨識權限宣告)
├── lib/
│   ├── main.dart             # 程式進入點與 Material 3 主題
│   ├── models/
│   │   └── reminder_item.dart        # 提醒項目資料模型與 JSON 序列化
│   ├── services/
│   │   ├── ai_service.dart           # Gemini AI 串接 + 離線規則解析引擎
│   │   ├── speech_service.dart       # 語音轉文字 (STT) 與語音朗讀 (TTS)
│   │   ├── notification_service.dart # 本地精確排程推播服務
│   │   └── storage_service.dart      # 本地持久化資料儲存 (SharedPreferences)
│   ├── screens/
│   │   ├── home_screen.dart          # 首頁儀表板與提醒清單
│   │   ├── edit_reminder_screen.dart # 手動新增/編輯頁面
│   │   └── settings_screen.dart      # API Key 設定與功能測試
│   └── widgets/
│       ├── voice_assistant_sheet.dart# 核心語音助理互動彈窗 (波紋動畫+語音確認)
│       ├── reminder_card.dart        # 提醒卡片元件
│       └── category_chip.dart        # 分類標籤元件
└── pubspec.yaml              # 套件相依性定義檔
```

---

## 🚀 如何在手機上安裝與執行

### 步驟 1：安裝 Flutter 開發環境 (若尚未安裝)
1. 前往 [Flutter 官網](https://docs.flutter.dev/get-started/install) 下載 Flutter SDK。
2. 解壓縮並將 `flutter/bin` 加入系統的環境變數 `PATH` 中。
3. 在終端機執行：
   ```bash
   flutter doctor
   ```

### 步驟 2：取得套件依賴
在專案根目錄下執行：
```bash
flutter pub get
```

### 步驟 3：安裝到手機上

#### 方式 A：Android 手機直接打包 APK 安裝（最簡單）
1. 在終端機執行打包指令：
   ```bash
   flutter build apk --release
   ```
2. 編譯完成後，產生的安裝檔位於：
   `build/app/outputs/flutter-apk/app-release.apk`
3. 將該 `.apk` 傳送至您的 Android 手機（透過 LINE、雲端硬碟或 USB 傳輸），點擊即可直接安裝！

#### 方式 B：手機連接電腦直接偵錯安裝（支援 iOS & Android）
1. **Android**：手機開啟「開發人員選項」並啟用「USB 偵錯」，用傳輸線連接電腦。
2. **iPhone**：將 iPhone 連接至 Mac，使用 Xcode 開啟 `ios/Runner.xcworkspace` 登入 Apple ID。
3. 執行執行指令：
   ```bash
   flutter run
   ```

---

## 🔑 設定 Google Gemini API Key (可選，推薦)

1. 開啟瀏覽器造訪 [Google AI Studio](https://aistudio.google.com/app/apikey)。
2. 登入 Google 帳號並免費建立一組 API Key。
3. 打開手機上的 App，點擊右上角「⚙️ 設定」按鈕。
4. 貼上您的 API Key 並點擊「儲存金鑰」與「測試連線」。
5. 完成！現在語音助理具備最強的自然口語推理與理解力！
