import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../models/reminder_item.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  bool _isInitialized = false;

  Future<void> init() async {
    if (_isInitialized) return;

    // 1. 初始化時區支援
    tz.initializeTimeZones();
    // 預設設為台北/台灣時區 (Asia/Taipei)
    try {
      tz.setLocalLocation(tz.getLocation('Asia/Taipei'));
    } catch (_) {
      // 若無則沿用 UTC 或預設
    }

    // 2. Android 通知設定
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');

    // 3. iOS 通知設定
    const darwinSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: darwinSettings,
    );

    await _notificationsPlugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (response) {
        print('使用者點擊通知，Payload: ${response.payload}');
      },
    );

    // 4. Android 13+ 請求通知權限
    final androidImpl = _notificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (androidImpl != null) {
      await androidImpl.requestNotificationsPermission();
      await androidImpl.requestExactAlarmsPermission();
    }

    _isInitialized = true;
  }

  /// 為單一提醒項目排程推播
  Future<void> scheduleReminder(ReminderItem item) async {
    if (item.isCompleted) return;
    if (item.reminderTime.isBefore(DateTime.now())) return;

    final id = item.id.hashCode;
    final scheduledTZ = tz.TZDateTime.from(item.reminderTime, tz.local);

    const androidDetails = AndroidNotificationDetails(
      'voice_reminder_channel',
      '語音提醒通知',
      channelDescription: '提醒您在指定時間完成口說記錄的各項代辦事項',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      icon: '@mipmap/ic_launcher',
    );

    const darwinDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: darwinDetails,
    );

    try {
      await _notificationsPlugin.zonedSchedule(
        id,
        '⏰ 提醒：${item.title}',
        '預定時間到了！別忘了完成「${item.title}」喔！',
        scheduledTZ,
        notificationDetails,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: item.id,
      );
      print('已成功排程通知: id=$id, 時間=$scheduledTZ, 事項=${item.title}');
    } catch (e) {
      print('排程通知發生錯誤: $e');
    }
  }

  /// 取消指定項目的排程通知
  Future<void> cancelReminder(ReminderItem item) async {
    final id = item.id.hashCode;
    await _notificationsPlugin.cancel(id);
    print('已取消通知: id=$id');
  }

  /// 測試用：立即發送推播通知
  Future<void> showInstantNotification({
    required String title,
    required String body,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'voice_reminder_test_channel',
      '測試通知頻道',
      channelDescription: '測試用通知',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );
    const darwinDetails = DarwinNotificationDetails();
    const details = NotificationDetails(android: androidDetails, iOS: darwinDetails);

    await _notificationsPlugin.show(
      DateTime.now().millisecond,
      title,
      body,
      details,
    );
  }

  /// 測試用：在 5 秒後發送推播通知（驗證延遲排程與背景喚醒）
  Future<void> scheduleTestNotification() async {
    final testTime = DateTime.now().add(const Duration(seconds: 5));
    final scheduledTZ = tz.TZDateTime.from(testTime, tz.local);

    const androidDetails = AndroidNotificationDetails(
      'voice_reminder_channel',
      '語音提醒通知',
      importance: Importance.max,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );
    const darwinDetails = DarwinNotificationDetails();
    const details = NotificationDetails(android: androidDetails, iOS: darwinDetails);

    await _notificationsPlugin.zonedSchedule(
      9999,
      '🎉 提醒功能測試成功！',
      '恭喜！您的手機通知排程系統運作完全正常。',
      scheduledTZ,
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }
}
