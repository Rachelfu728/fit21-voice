import 'package:flutter/material.dart';
import '../services/ai_service.dart';
import '../services/notification_service.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _storage = StorageService();
  final _speech = SpeechService();
  final _notifications = NotificationService();
  final _ai = AIService();

  late TextEditingController _apiKeyController;
  bool _obscureKey = true;
  bool _ttsEnabled = true;
  double _ttsRate = 0.5;
  String _locale = 'zh_TW';
  bool _isTestingApi = false;

  @override
  void initState() {
    super.initState();
    _apiKeyController = TextEditingController(text: _storage.getApiKey());
    _ttsEnabled = _storage.isTtsEnabled();
    _ttsRate = _storage.getTtsRate();
    _locale = _storage.getSpeechLocale();
  }

  @override
  void dispose() {
    _apiKeyController.dispose();
    super.dispose();
  }

  Future<void> _saveApiKey() async {
    await _storage.setApiKey(_apiKeyController.text);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('API Key 已儲存！')),
      );
    }
  }

  Future<void> _testApiKey() async {
    final key = _apiKeyController.text.trim();
    if (key.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('請先輸入 API Key 再測試')),
      );
      return;
    }

    setState(() {
      _isTestingApi = true;
    });

    await _storage.setApiKey(key);
    final res = await _ai.parseVoiceInput('明天早上9點提醒我看醫生');

    setState(() {
      _isTestingApi = false;
    });

    if (mounted) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(res.success ? '✅ API 連線成功！' : '❌ 連線或解析失敗'),
          content: Text(res.success
              ? 'AI 成功解析：\n事項：${res.title}\n時間：${res.targetTime}\n回覆：${res.replyMessage}'
              : '錯誤訊息：${res.error ?? "請檢查金鑰是否正確及網路連線。"}'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('確定'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('設定與功能測試'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // 1. Gemini AI 設定
          _buildSectionHeader('🤖 Google Gemini AI 設定', theme),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Gemini API Key',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    '串接雲端 AI 可獲得最強的自然口語理解能力。若未填寫，App 會自動使用內建離線規則引擎解析。',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _apiKeyController,
                    obscureText: _obscureKey,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      hintText: '貼上 AI Studio 取得的 API Key...',
                      prefixIcon: const Icon(Icons.key_rounded),
                      suffixIcon: IconButton(
                        icon: Icon(_obscureKey ? Icons.visibility_off : Icons.visibility),
                        onPressed: () => setState(() => _obscureKey = !_obscureKey),
                      ),
                    ),
                    onChanged: (val) => _storage.setApiKey(val),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      ElevatedButton.icon(
                        onPressed: _saveApiKey,
                        icon: const Icon(Icons.check, size: 16),
                        label: const Text('儲存金鑰'),
                      ),
                      const SizedBox(width: 8),
                      OutlinedButton.icon(
                        onPressed: _isTestingApi ? null : _testApiKey,
                        icon: _isTestingApi
                            ? const SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.play_arrow_rounded, size: 16),
                        label: const Text('測試連線'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '💡 可至 Google AI Studio (aistudio.google.com) 免費申請個人專屬 API Key。',
                    style: TextStyle(fontSize: 11, color: theme.colorScheme.primary),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // 2. 語音與播報設定
          _buildSectionHeader('🔊 語音辨識與回覆 (TTS/STT)', theme),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Column(
              children: [
                SwitchListTile(
                  title: const Text('語音自動回覆朗讀'),
                  subtitle: const Text('新增提醒後由語音助理唸出確認訊息'),
                  value: _ttsEnabled,
                  onChanged: (val) async {
                    setState(() => _ttsEnabled = val);
                    await _storage.setTtsEnabled(val);
                  },
                ),
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      const Text('語速調整：'),
                      Expanded(
                        child: Slider(
                          value: _ttsRate,
                          min: 0.2,
                          max: 1.0,
                          divisions: 8,
                          label: '${_ttsRate.toStringAsFixed(1)}x',
                          onChanged: (val) async {
                            setState(() => _ttsRate = val);
                            await _storage.setTtsRate(val);
                          },
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.volume_up_rounded),
                        tooltip: '試聽語音',
                        onPressed: () => _speech.speak('好的！已為您設定下午三點的提醒。'),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  title: const Text('語音辨識語言'),
                  trailing: DropdownButton<String>(
                    value: _locale,
                    underline: const SizedBox(),
                    items: const [
                      DropdownMenuItem(value: 'zh_TW', child: Text('繁體中文 (台灣)')),
                      DropdownMenuItem(value: 'zh_CN', child: Text('簡體中文')),
                      DropdownMenuItem(value: 'en_US', child: Text('English (US)')),
                    ],
                    onChanged: (val) async {
                      if (val != null) {
                        setState(() => _locale = val);
                        await _storage.setSpeechLocale(val);
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 3. 系統通知測試
          _buildSectionHeader('⏰ 系統提醒通知測試', theme),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('測試手機推播通知功能，確保系統在指定時間能正常彈出通知與響鈴：'),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () {
                            _notifications.showInstantNotification(
                              title: '🔔 提醒測試通知',
                              body: '這是一則即時測試通知，您的手機通知功能正常！',
                            );
                          },
                          icon: const Icon(Icons.notifications_active_rounded),
                          label: const Text('立即發送通知'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () async {
                            await _notifications.scheduleTestNotification();
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('已設定 5 秒後推播測試通知，您可以鎖定手機螢幕觀察！'),
                                  duration: Duration(seconds: 4),
                                ),
                              );
                            }
                          },
                          icon: const Icon(Icons.timer_outlined),
                          label: const Text('5秒後排程測試'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // 關於 Fit21
          Center(
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset(
                    'assets/images/app_logo.png',
                    width: 52,
                    height: 52,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Fit21 語音提醒助理 v1.0.0\n專為個人效率與健康習慣打造的口說提醒神器',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: theme.hintColor),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }
}
