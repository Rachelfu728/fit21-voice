import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../models/reminder_item.dart';
import '../services/ai_service.dart';
import '../services/notification_service.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import 'category_chip.dart';

enum VoiceState { listening, analyzing, parsed, error }

class VoiceAssistantSheet extends StatefulWidget {
  final VoidCallback onReminderCreated;

  const VoiceAssistantSheet({
    super.key,
    required this.onReminderCreated,
  });

  @override
  State<VoiceAssistantSheet> createState() => _VoiceAssistantSheetState();
}

class _VoiceAssistantSheetState extends State<VoiceAssistantSheet>
    with SingleTickerProviderStateMixin {
  final SpeechService _speechService = SpeechService();
  final AIService _aiService = AIService();
  final StorageService _storageService = StorageService();
  final NotificationService _notificationService = NotificationService();

  VoiceState _state = VoiceState.listening;
  String _spokenText = '';
  double _soundLevel = 0.0;
  AIParseResult? _parseResult;
  String _errorMessage = '';

  late AnimationController _animController;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _startListening();
  }

  @override
  void dispose() {
    _animController.dispose();
    _speechService.stopListening();
    _speechService.stopSpeaking();
    super.dispose();
  }

  Future<void> _startListening() async {
    setState(() {
      _state = VoiceState.listening;
      _spokenText = '';
      _errorMessage = '';
      _parseResult = null;
    });

    final ready = await _speechService.init();
    if (!ready) {
      if (mounted) {
        setState(() {
          _state = VoiceState.error;
          _errorMessage = '無法啟用麥克風或語音辨識，請至手機設定允許麥克風權限。';
        });
      }
      return;
    }

    await _speechService.startListening(
      onResult: (text, isFinal) {
        if (mounted) {
          setState(() {
            _spokenText = text;
          });
          if (isFinal && text.trim().isNotEmpty) {
            _analyzeText(text);
          }
        }
      },
      onSoundLevel: (level) {
        if (mounted) {
          setState(() {
            _soundLevel = level;
          });
        }
      },
    );
  }

  Future<void> _analyzeText(String text) async {
    await _speechService.stopListening();

    if (text.trim().isEmpty) {
      setState(() {
        _state = VoiceState.error;
        _errorMessage = '沒有偵測到說話內容，請對著麥克風再試一次。';
      });
      return;
    }

    setState(() {
      _state = VoiceState.analyzing;
    });

    final result = await _aiService.parseVoiceInput(text);

    if (!mounted) return;

    if (result.success) {
      setState(() {
        _state = VoiceState.parsed;
        _parseResult = result;
      });

      // 語音朗讀確認回覆
      await _speechService.speak(result.replyMessage);
    } else {
      setState(() {
        _state = VoiceState.error;
        _errorMessage = result.replyMessage;
      });
    }
  }

  Future<void> _confirmAndSave() async {
    if (_parseResult == null) return;

    final item = ReminderItem(
      id: const Uuid().v4(),
      title: _parseResult!.title,
      reminderTime: _parseResult!.targetTime,
      category: _parseResult!.category,
      rawVoiceInput: _spokenText,
    );

    // 儲存至本地快顯
    await _storageService.saveReminder(item);

    // 設定定時系統推播通知
    await _notificationService.scheduleReminder(item);

    widget.onReminderCreated();

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.check_circle_rounded, color: Colors.white),
              const SizedBox(width: 8),
              Expanded(child: Text('已設定提醒：${item.title}')),
            ],
          ),
          backgroundColor: const Color(0xFF16A34A),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 25,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 頂部小拉條
            Container(
              width: 44,
              height: 5,
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.3),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            const SizedBox(height: 16),

            // 狀態內容區
            if (_state == VoiceState.listening) _buildListeningView(theme),
            if (_state == VoiceState.analyzing) _buildAnalyzingView(theme),
            if (_state == VoiceState.parsed) _buildParsedView(theme),
            if (_state == VoiceState.error) _buildErrorView(theme),

            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  /// 麥克風核心語音收音畫面
  Widget _buildListeningView(ThemeData theme) {
    return Column(
      children: [
        // 頂部 Fit21 助理問候列
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.asset(
                'assets/images/app_logo.png',
                width: 38,
                height: 38,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.smart_toy_rounded,
                  color: Color(0xFF16A34A),
                  size: 32,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Flexible(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF16A34A).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFF16A34A).withOpacity(0.2)),
                ),
                child: const Text(
                  'Fit21 助理正在聽您說話...',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF16A34A),
                  ),
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 24),

        // 🌟 核心：超大震撼動態麥克風畫面 (具備多層水波音浪與音壓互動效果)
        _buildDynamicMicrophone(),

        const SizedBox(height: 16),

        // 音波頻譜跳動條
        _buildAudioWaveBars(),

        const SizedBox(height: 18),

        // 即時聽到的語音口說文字顯示框
        Container(
          width: double.infinity,
          constraints: const BoxConstraints(minHeight: 64),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: _spokenText.isNotEmpty
                  ? const Color(0xFF16A34A).withOpacity(0.5)
                  : Colors.grey.withOpacity(0.2),
              width: _spokenText.isNotEmpty ? 1.5 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Text(
            _spokenText.isEmpty ? '請說出要提醒的事項與時間...\n例如：「明天下午3點提醒我去郵局」' : _spokenText,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              height: 1.4,
              color: _spokenText.isEmpty ? theme.hintColor : theme.textTheme.bodyLarge?.color,
              fontWeight: _spokenText.isEmpty ? FontWeight.normal : FontWeight.w600,
            ),
          ),
        ),

        const SizedBox(height: 20),

        // 底部控制按鈕
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () {
                  _speechService.stopListening();
                  Navigator.pop(context);
                },
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                child: const Text('取消'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: _spokenText.isNotEmpty ? () => _analyzeText(_spokenText) : null,
                icon: const Icon(Icons.check_rounded, size: 20),
                label: const Text('說完了，開始分析', style: TextStyle(fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF16A34A),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  elevation: 2,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// 超大動態聲波互動麥克風元件
  Widget _buildDynamicMicrophone() {
    return AnimatedBuilder(
      animation: _animController,
      builder: (context, child) {
        // 隨聲音音量與呼吸動畫擴散外環
        final pulse = _animController.value;
        final soundBoost = (_soundLevel * 0.05).clamp(0.0, 0.4);

        return GestureDetector(
          onTap: () {
            if (_spokenText.isNotEmpty) {
              _analyzeText(_spokenText);
            }
          },
          child: SizedBox(
            width: 190,
            height: 190,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // 第一層最外圈聲波環
                Container(
                  width: 160 + (pulse * 30) + (soundBoost * 40),
                  height: 160 + (pulse * 30) + (soundBoost * 40),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF22C55E).withOpacity((0.15 - (pulse * 0.1)).clamp(0.02, 0.2)),
                  ),
                ),

                // 第二層中間光暈環
                Container(
                  width: 135 + (pulse * 18) + (soundBoost * 25),
                  height: 135 + (pulse * 18) + (soundBoost * 25),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF16A34A).withOpacity((0.25 - (pulse * 0.1)).clamp(0.08, 0.3)),
                  ),
                ),

                // 第三層實體立體麥克風主體
                Container(
                  width: 105,
                  height: 105,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF22C55E), // 鮮亮綠
                        Color(0xFF15803D), // 深綠
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF16A34A).withOpacity(0.45),
                        blurRadius: 22,
                        spreadRadius: 4,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // 內部白色圓環細節
                      Container(
                        width: 93,
                        height: 93,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.35),
                            width: 2,
                          ),
                        ),
                      ),
                      // 🌟 焦點：高解析麥克風圖示
                      const Icon(
                        Icons.mic_rounded,
                        color: Colors.white,
                        size: 56,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// 麥克風下方的跳動音波頻譜
  Widget _buildAudioWaveBars() {
    return AnimatedBuilder(
      animation: _animController,
      builder: (context, child) {
        final val = _animController.value;
        final heights = [
          10 + math.sin(val * math.pi) * 12 + (_soundLevel * 2),
          16 + math.cos(val * math.pi) * 16 + (_soundLevel * 3),
          24 + math.sin((val + 0.3) * math.pi) * 20 + (_soundLevel * 4),
          32 + math.cos((val + 0.5) * math.pi) * 24 + (_soundLevel * 5),
          24 + math.sin((val + 0.7) * math.pi) * 20 + (_soundLevel * 4),
          16 + math.cos(val * math.pi) * 16 + (_soundLevel * 3),
          10 + math.sin(val * math.pi) * 12 + (_soundLevel * 2),
        ];

        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: heights.map((h) {
            final clampedHeight = h.clamp(6.0, 48.0);
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: 4,
              height: clampedHeight,
              decoration: BoxDecoration(
                color: const Color(0xFF16A34A).withOpacity(0.85),
                borderRadius: BorderRadius.circular(4),
              ),
            );
          }).toList(),
        );
      },
    );
  }

  /// AI 分析中動畫
  Widget _buildAnalyzingView(ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 36),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: Image.asset(
              'assets/images/app_logo.png',
              width: 72,
              height: 72,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 20),
          const SizedBox(
            width: 36,
            height: 36,
            child: CircularProgressIndicator(
              color: Color(0xFF16A34A),
              strokeWidth: 3.5,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            '🤖 Fit21 AI 正在智能解析...',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            '「$_spokenText」',
            style: TextStyle(fontStyle: FontStyle.italic, color: theme.hintColor),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  /// 解析成果確認畫面
  Widget _buildParsedView(ThemeData theme) {
    final res = _parseResult!;
    final timeStr = DateFormat('yyyy/MM/dd ah:mm (E)', 'zh_TW').format(res.targetTime);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle_rounded, color: Color(0xFF16A34A), size: 26),
            const SizedBox(width: 8),
            const Text(
              '已成功理解您的提醒！',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF16A34A),
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),

        // AI 解析成果卡片
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFF16A34A).withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF16A34A).withOpacity(0.08),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.notifications_active_rounded, color: Color(0xFF16A34A), size: 24),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      res.title,
                      style: const TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const Divider(height: 24),
              Row(
                children: [
                  const Icon(Icons.access_time_rounded, color: Colors.teal, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    '提醒時間：$timeStr',
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('分類：', style: TextStyle(fontSize: 13, color: Colors.grey)),
                  CategoryChip(category: res.category, isSelected: true),
                ],
              ),
              const SizedBox(height: 14),
              // AI 回覆泡泡
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF16A34A).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.record_voice_over_rounded, size: 18, color: Color(0xFF16A34A)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        res.replyMessage,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF15803D),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        // 按鈕區
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _startListening,
                icon: const Icon(Icons.mic_rounded, size: 18),
                label: const Text('重說一次'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: _confirmAndSave,
                icon: const Icon(Icons.alarm_add_rounded),
                label: const Text('確認並設定提醒', style: TextStyle(fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF16A34A),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  /// 錯誤狀態畫面
  Widget _buildErrorView(ThemeData theme) {
    return Column(
      children: [
        const Icon(Icons.mic_off_rounded, color: Colors.redAccent, size: 54),
        const SizedBox(height: 12),
        const Text(
          '收音或解析遇到問題',
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          _errorMessage,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.grey),
        ),
        const SizedBox(height: 22),
        ElevatedButton.icon(
          onPressed: _startListening,
          icon: const Icon(Icons.refresh_rounded),
          label: const Text('點此重新對著麥克風說話'),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF16A34A),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          ),
        ),
      ],
    );
  }
}
