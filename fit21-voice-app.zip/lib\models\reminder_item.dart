import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ReminderItem {
  final String id;
  final String title;
  final DateTime reminderTime;
  final bool isCompleted;
  final String category; // 'work', 'life', 'urgent', 'health', 'other'
  final String rawVoiceInput;
  final DateTime createdAt;
  final String? note;

  ReminderItem({
    required this.id,
    required this.title,
    required this.reminderTime,
    this.isCompleted = false,
    this.category = 'other',
    this.rawVoiceInput = '',
    DateTime? createdAt,
    this.note,
  }) : createdAt = createdAt ?? DateTime.now();

  bool get isOverdue => !isCompleted && reminderTime.isBefore(DateTime.now());

  bool get isToday {
    final now = DateTime.now();
    return reminderTime.year == now.year &&
        reminderTime.month == now.month &&
        reminderTime.day == now.day;
  }

  bool get isTomorrow {
    final tomorrow = DateTime.now().add(const Duration(days: 1));
    return reminderTime.year == tomorrow.year &&
        reminderTime.month == tomorrow.month &&
        reminderTime.day == tomorrow.day;
  }

  String get formattedDate {
    if (isToday) return '今天';
    if (isTomorrow) return '明天';
    return DateFormat('M月d日 (E)', 'zh_TW').format(reminderTime);
  }

  String get formattedTime {
    return DateFormat('ah:mm', 'zh_TW').format(reminderTime);
  }

  String get categoryLabel {
    switch (category) {
      case 'work':
        return '工作';
      case 'life':
        return '生活';
      case 'urgent':
        return '緊急';
      case 'health':
        return '健康';
      default:
        return '備忘';
    }
  }

  Color get categoryColor {
    switch (category) {
      case 'work':
        return Colors.indigoAccent;
      case 'life':
        return Colors.teal;
      case 'urgent':
        return Colors.deepOrangeAccent;
      case 'health':
        return Colors.green;
      default:
        return Colors.blueGrey;
    }
  }

  IconData get categoryIcon {
    switch (category) {
      case 'work':
        return Icons.work_outline;
      case 'life':
        return Icons.home_outlined;
      case 'urgent':
        return Icons.priority_high;
      case 'health':
        return Icons.favorite_border;
      default:
        return Icons.lightbulb_outline;
    }
  }

  ReminderItem copyWith({
    String? id,
    String? title,
    DateTime? reminderTime,
    bool? isCompleted,
    String? category,
    String? rawVoiceInput,
    DateTime? createdAt,
    String? note,
  }) {
    return ReminderItem(
      id: id ?? this.id,
      title: title ?? this.title,
      reminderTime: reminderTime ?? this.reminderTime,
      isCompleted: isCompleted ?? this.isCompleted,
      category: category ?? this.category,
      rawVoiceInput: rawVoiceInput ?? this.rawVoiceInput,
      createdAt: createdAt ?? this.createdAt,
      note: note ?? this.note,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'reminderTime': reminderTime.toIso8601String(),
      'isCompleted': isCompleted,
      'category': category,
      'rawVoiceInput': rawVoiceInput,
      'createdAt': createdAt.toIso8601String(),
      'note': note,
    };
  }

  factory ReminderItem.fromJson(Map<String, dynamic> json) {
    return ReminderItem(
      id: json['id'] as String,
      title: json['title'] as String,
      reminderTime: DateTime.parse(json['reminderTime'] as String),
      isCompleted: json['isCompleted'] as bool? ?? false,
      category: json['category'] as String? ?? 'other',
      rawVoiceInput: json['rawVoiceInput'] as String? ?? '',
      createdAt: json['createdAt'] != null
          ? DateTime.parse(json['createdAt'] as String)
          : DateTime.now(),
      note: json['note'] as String?,
    );
  }
}
