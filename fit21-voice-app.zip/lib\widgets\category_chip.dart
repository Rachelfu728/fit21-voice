import 'package:flutter/material.dart';

class CategoryChip extends StatelessWidget {
  final String category;
  final bool isSelected;
  final VoidCallback? onTap;

  const CategoryChip({
    super.key,
    required this.category,
    this.isSelected = false,
    this.onTap,
  });

  String get _label {
    switch (category) {
      case 'work':
        return '工作';
      case 'life':
        return '生活';
      case 'urgent':
        return '緊急';
      case 'health':
        return '健康';
      default:
        return '備忘';
    }
  }

  Color get _color {
    switch (category) {
      case 'work':
        return const Color(0xFF3F51B5);
      case 'life':
        return const Color(0xFF009688);
      case 'urgent':
        return const Color(0xFFE64A19);
      case 'health':
        return const Color(0xFF2E7D32);
      default:
        return const Color(0xFF546E7A);
    }
  }

  IconData get _icon {
    switch (category) {
      case 'work':
        return Icons.work_rounded;
      case 'life':
        return Icons.coffee_rounded;
      case 'urgent':
        return Icons.notification_important_rounded;
      case 'health':
        return Icons.favorite_rounded;
      default:
        return Icons.lightbulb_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: isSelected ? _color : _color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? _color : _color.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              _icon,
              size: 14,
              color: isSelected ? Colors.white : _color,
            ),
            const SizedBox(width: 4),
            Text(
              _label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                color: isSelected ? Colors.white : _color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
