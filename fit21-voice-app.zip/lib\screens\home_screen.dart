import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/reminder_item.dart';
import '../services/notification_service.dart';
import '../services/storage_service.dart';
import '../widgets/reminder_card.dart';
import '../widgets/voice_assistant_sheet.dart';
import 'edit_reminder_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final StorageService _storage = StorageService();
  final NotificationService _notifications = NotificationService();

  List<ReminderItem> _reminders = [];
  String _activeTab = 'all'; // 'all', 'today', 'upcoming', 'completed'
  String? _selectedCategory; // null = all

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    setState(() {
      _reminders = _storage.getReminders();
    });
  }

  List<ReminderItem> get _filteredReminders {
    return _reminders.where((item) {
      // 類別過濾
      if (_selectedCategory != null && item.category != _selectedCategory) {
        return false;
      }

      // 頁籤過濾
      switch (_activeTab) {
        case 'today':
          return !item.isCompleted && item.isToday;
        case 'upcoming':
          return !item.isCompleted && item.reminderTime.isAfter(DateTime.now());
        case 'completed':
          return item.isCompleted;
        default: // 'all'
          return true;
      }
    }).toList();
  }

  void _openVoiceAssistant() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => VoiceAssistantSheet(
        onReminderCreated: _loadData,
      ),
    );
  }

  Future<void> _toggleComplete(ReminderItem item) async {
    final updated = await _storage.toggleComplete(item.id);
    if (updated != null) {
      if (updated.isCompleted) {
        await _notifications.cancelReminder(item);
      } else {
        await _notifications.scheduleReminder(updated);
      }
      _loadData();
    }
  }

  Future<void> _deleteItem(ReminderItem item) async {
    await _storage.deleteReminder(item.id);
    await _notifications.cancelReminder(item);
    _loadData();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('已刪除「${item.title}」'),
          action: SnackBarAction(
            label: '復原',
            onPressed: () async {
              await _storage.saveReminder(item);
              await _notifications.scheduleReminder(item);
              _loadData();
            },
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Future<void> _snoozeItem(ReminderItem item) async {
    final newTime = DateTime.now().add(const Duration(minutes: 15));
    final updated = item.copyWith(reminderTime: newTime, isCompleted: false);
    await _storage.saveReminder(updated);
    await _notifications.scheduleReminder(updated);
    _loadData();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('已為您延後 15 分鐘提醒'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Future<void> _navigateToEdit([ReminderItem? item]) async {
    final res = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (context) => EditReminderScreen(initialItem: item),
      ),
    );
    if (res == true) {
      _loadData();
    }
  }

  String get _greeting {
    final hour = DateTime.now().hour;
    if (hour < 6) return '夜深了，注意休息';
    if (hour < 11) return '早安！今天準備做些什麼？';
    if (hour < 14) return '午安！別忘了吃午餐喔';
    if (hour < 18) return '下午好！繼續加油';
    return '晚安！回顧一下今天的事項吧';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final now = DateTime.now();
    final dateStr = DateFormat('M月d日 EEEE', 'zh_TW').format(now);

    final todayCount = _reminders.where((e) => !e.isCompleted && e.isToday).length;
    final totalPending = _reminders.where((e) => !e.isCompleted).length;

    final items = _filteredReminders;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/images/app_logo.png',
                width: 32,
                height: 32,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.alarm_rounded,
                  color: Color(0xFF16A34A),
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Text('Fit21 語音提醒助理'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded),
            tooltip: '手動新增',
            onPressed: () => _navigateToEdit(),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: '設定',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // 頂部儀表板卡片
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF16A34A),
                    Color(0xFF0D9488),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF16A34A).withOpacity(0.35),
                    blurRadius: 15,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              dateStr,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Text(
                                '口說即記',
                                style: TextStyle(color: Colors.white, fontSize: 10),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _greeting,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            _buildStatChip('今日提醒', '$todayCount 個'),
                            const SizedBox(width: 8),
                            _buildStatChip('總未完成', '$totalPending 個'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  // Fit21 吉祥物機器人小圖
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      padding: const EdgeInsets.all(3),
                      color: Colors.white.withOpacity(0.25),
                      child: Image.asset(
                        'assets/images/app_logo.png',
                        width: 68,
                        height: 68,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 分類與狀態切換頁籤
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                _buildTabChip('全部', 'all'),
                _buildTabChip('今日', 'today'),
                _buildTabChip('即將到來', 'upcoming'),
                _buildTabChip('已完成', 'completed'),
              ],
            ),
          ),

          const SizedBox(height: 4),

          // 清單列表
          Expanded(
            child: items.isEmpty
                ? _buildEmptyState(theme)
                : RefreshIndicator(
                    onRefresh: () async => _loadData(),
                    child: ListView.builder(
                      padding: const EdgeInsets.only(top: 8, bottom: 90),
                      itemCount: items.length,
                      itemBuilder: (context, index) {
                        final item = items[index];
                        return ReminderCard(
                          item: item,
                          onToggle: (_) => _toggleComplete(item),
                          onDelete: () => _deleteItem(item),
                          onEdit: () => _navigateToEdit(item),
                          onSnooze: () => _snoozeItem(item),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),

      // 核心語音輸入浮動按鈕
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Container(
        height: 64,
        margin: const EdgeInsets.symmetric(horizontal: 20),
        child: ElevatedButton.icon(
          onPressed: _openVoiceAssistant,
          icon: Container(
            padding: const EdgeInsets.all(6),
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
            ),
            child: Icon(Icons.mic_rounded, color: theme.colorScheme.primary, size: 24),
          ),
          label: const Text(
            '點擊口說提醒事項',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 0.5),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: theme.colorScheme.primary,
            foregroundColor: Colors.white,
            elevation: 8,
            shadowColor: theme.colorScheme.primary.withOpacity(0.5),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(32)),
            padding: const EdgeInsets.symmetric(horizontal: 24),
          ),
        ),
      ),
    );
  }

  Widget _buildStatChip(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.18),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(width: 6),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabChip(String label, String tabKey) {
    final isSelected = _activeTab == tabKey;
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (selected) {
          if (selected) {
            setState(() {
              _activeTab = tabKey;
            });
          }
        },
        selectedColor: theme.colorScheme.primary.withOpacity(0.18),
        labelStyle: TextStyle(
          color: isSelected ? theme.colorScheme.primary : theme.textTheme.bodyMedium?.color,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(
            color: isSelected ? theme.colorScheme.primary : Colors.grey.withOpacity(0.2),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Image.asset(
                'assets/images/app_logo.png',
                width: 96,
                height: 96,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.mic_none_rounded,
                    size: 64,
                    color: Color(0xFF16A34A),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              '目前沒有任何提醒事項',
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              '點擊下方按鈕，對著手機說：\n「明天下午3點提醒我去開會」\nAI 就會為您自動設定並準時通知！',
              textAlign: TextAlign.center,
              style: TextStyle(color: theme.hintColor, fontSize: 13, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}
