import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'storage_service.dart';

class SpeechService {
  static final SpeechService _instance = SpeechService._internal();
  factory SpeechService() => _instance;
  SpeechService._internal();

  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _isSpeechInitialized = false;
  bool _isListening = false;
  double _soundLevel = 0.0;

  bool get isListening => _isListening;
  double get soundLevel => _soundLevel;

  /// 初始化語音辨識與 TTS
  Future<bool> init() async {
    // 請求麥克風權限
    final micStatus = await Permission.microphone.request();
    if (!micStatus.isGranted) {
      print('麥克風權限未被授權');
    }

    // 初始化語音辨識
    try {
      _isSpeechInitialized = await _speech.initialize(
        onError: (val) => print('語音辨識錯誤: $val'),
        onStatus: (val) {
          print('語音辨識狀態: $val');
          if (val == 'done' || val == 'notListening') {
            _isListening = false;
          }
        },
      );
    } catch (e) {
      print('SpeechToText 初始化異常: $e');
    }

    // 初始化 TTS 語音朗讀
    try {
      await _tts.setLanguage('zh-TW');
      await _tts.setSpeechRate(StorageService().getTtsRate());
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.0);

      // iOS 音訊設置相容性
      await _tts.setIosAudioCategory(
        IosTextToSpeechAudioCategory.ambientSolo,
        [
          IosTextToSpeechAudioCategoryOptions.allowBluetooth,
          IosTextToSpeechAudioCategoryOptions.defaultToSpeaker,
        ],
      );
    } catch (e) {
      print('FlutterTts 初始化異常: $e');
    }

    return _isSpeechInitialized;
  }

  /// 開始監聽口說語音
  Future<void> startListening({
    required Function(String text, bool isFinal) onResult,
    Function(double level)? onSoundLevel,
  }) async {
    if (!_isSpeechInitialized) {
      final ok = await init();
      if (!ok) return;
    }

    if (_speech.isListening) {
      await _speech.stop();
    }

    _isListening = true;

    final locale = StorageService().getSpeechLocale();

    await _speech.listen(
      localeId: locale,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
      onResult: (result) {
        onResult(result.recognizedWords, result.finalResult);
      },
      onSoundLevelChange: (level) {
        _soundLevel = level;
        if (onSoundLevel != null) {
          onSoundLevel(level);
        }
      },
      cancelOnError: false,
      listenMode: stt.ListenMode.confirmation,
    );
  }

  /// 停止監聽
  Future<void> stopListening() async {
    _isListening = false;
    await _speech.stop();
  }

  /// 取消辨識
  Future<void> cancelListening() async {
    _isListening = false;
    await _speech.cancel();
  }

  /// 語音朗讀文字
  Future<void> speak(String text) async {
    if (!StorageService().isTtsEnabled()) return;
    if (text.trim().isEmpty) return;

    try {
      await _tts.stop();
      await _tts.setSpeechRate(StorageService().getTtsRate());
      await _tts.speak(text);
    } catch (e) {
      print('TTS 朗讀錯誤: $e');
    }
  }

  /// 停止語音朗讀
  Future<void> stopSpeaking() async {
    try {
      await _tts.stop();
    } catch (e) {
      print('TTS 停止錯誤: $e');
    }
  }
}
