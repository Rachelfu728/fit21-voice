import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'storage_service.dart';

class AIParseResult {
  final bool success;
  final String title;
  final DateTime targetTime;
  final String category; // 'work', 'life', 'urgent', 'health', 'other'
  final String replyMessage;
  final String? error;

  AIParseResult({
    required this.success,
    required this.title,
    required this.targetTime,
    required this.category,
    required this.replyMessage,
    this.error,
  });
}

class AIService {
  static final AIService _instance = AIService._internal();
  factory AIService() => _instance;
  AIService._internal();

  /// 主要解析入口：若有 API Key 則使用 Gemini AI，失敗或無 Key 則無縫切換本機備用解析引擎
  Future<AIParseResult> parseVoiceInput(String text) async {
    final cleanInput = text.trim();
    if (cleanInput.isEmpty) {
      return AIParseResult(
        success: false,
        title: '',
        targetTime: DateTime.now(),
        category: 'other',
        replyMessage: '我沒有聽清楚，請再說一次好嗎？',
        error: '輸入為空',
      );
    }

    final apiKey = StorageService().getApiKey();

    if (apiKey.isNotEmpty) {
      try {
        final geminiResult = await _callGeminiApi(cleanInput, apiKey);
        if (geminiResult != null) {
          return geminiResult;
        }
      } catch (e) {
        print('Gemini API 請求失敗，轉用本地規則解析: $e');
      }
    }

    // 本地規則與語意解析 (離線或無 API Key 時運作)
    return _parseWithLocalRules(cleanInput);
  }

  /// 呼叫 Gemini 1.5 Flash 進行智能語意萃取
  Future<AIParseResult?> _callGeminiApi(String text, String apiKey) async {
    final now = DateTime.now();
    final nowStr = DateFormat('yyyy-MM-dd HH:mm (EEEE)').format(now);

    final url = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey',
    );

    final systemInstruction = '''
你是一個專注於個人代辦與定時提醒的手機語音助理。
現在的時間是：$nowStr (ISO: ${now.toIso8601String()})。

使用者會用口語說出他想要記住或被提醒的事情。
請分析使用者的口說文字，並嚴格只輸出 JSON 格式，不要包含任何額外的 Markdown 標記或文字：

JSON 欄位規範：
1. "title": 事項的核心內容（去除「提醒我」、「記得」等冗贅助詞，簡明扼要）。
2. "targetTime": 目標提醒時間，必須是精確的 ISO 8601 格式字串（例如 "2026-10-04T15:30:00"）。若使用者未指定確切時間，請預設為目前時間之後的 1 小時，或今日/明日合理時間。
3. "category": 分類，限選其中一個：["work", "life", "urgent", "health", "other"]。
4. "replyMessage": 給使用者的簡潔親切語音回覆（繁體中文，30字以內），明確說明已記錄的事項與時間。
''';

    final body = jsonEncode({
      "contents": [
        {
          "role": "user",
          "parts": [
            {
              "text": "使用者口說內容: \"$text\""
            }
          ]
        }
      ],
      "systemInstruction": {
        "parts": [
          {"text": systemInstruction}
        ]
      },
      "generationConfig": {
        "temperature": 0.2,
        "responseMimeType": "application/json"
      }
    });

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: body,
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final rawText = data['candidates']?[0]?['content']?['parts']?[0]?['text'] as String?;
      if (rawText != null) {
        final parsed = jsonDecode(rawText.trim());
        final title = (parsed['title'] as String?)?.trim() ?? text;
        final targetTimeStr = parsed['targetTime'] as String?;
        final category = parsed['category'] as String? ?? 'other';
        final replyMessage = parsed['replyMessage'] as String? ?? '好的，已經為您設定提醒。';

        DateTime targetTime = now.add(const Duration(hours: 1));
        if (targetTimeStr != null) {
          try {
            targetTime = DateTime.parse(targetTimeStr);
          } catch (_) {}
        }

        return AIParseResult(
          success: true,
          title: title,
          targetTime: targetTime,
          category: category,
          replyMessage: replyMessage,
        );
      }
    } else {
      print('Gemini API 回應狀態碼非 200: ${response.statusCode}, 內容: ${response.body}');
    }
    return null;
  }

  /// 本機智慧規則解析器 (免連線、免 API Key)
  AIParseResult _parseWithLocalRules(String text) {
    final now = DateTime.now();
    DateTime targetTime = now;
    bool timeDetected = false;

    // 1. 偵測相對分鐘 ("10分鐘後", "半小時後")
    final minMatch = RegExp(r'(\d+)\s*(?:個)?分鐘後').firstMatch(text);
    if (minMatch != null) {
      final mins = int.tryParse(minMatch.group(1)!) ?? 10;
      targetTime = now.add(Duration(minutes: mins));
      timeDetected = true;
    } else if (text.contains('半小時後')) {
      targetTime = now.add(const Duration(minutes: 30));
      timeDetected = true;
    }

    // 2. 偵測相對小時 ("2小時後", "1個小時後")
    final hourMatch = RegExp(r'(\d+)\s*(?:個)?小時後').firstMatch(text);
    if (!timeDetected && hourMatch != null) {
      final hours = int.tryParse(hourMatch.group(1)!) ?? 1;
      targetTime = now.add(Duration(hours: hours));
      timeDetected = true;
    }

    // 3. 偵測日期關鍵字 ("明天", "後天", "今天")
    int dayOffset = 0;
    if (text.contains('大後天')) {
      dayOffset = 3;
    } else if (text.contains('後天')) {
      dayOffset = 2;
    } else if (text.contains('明天') || text.contains('明早')) {
      dayOffset = 1;
    } else if (text.contains('今天')) {
      dayOffset = 0;
    }

    // 4. 偵測時刻 ("下午3點", "早上9點半", "14點30分")
    final timeRegex = RegExp(r'(早上|上午|中午|下午|晚上)?\s*(\d{1,2})\s*(?:點|:|時)\s*(?:(\d{1,2})|半)?');
    final match = timeRegex.firstMatch(text);

    if (!timeDetected && (dayOffset > 0 || match != null)) {
      int hour = 9; // 預設上午9點
      int minute = 0;

      if (match != null) {
        final period = match.group(1);
        var parsedHour = int.tryParse(match.group(2)!) ?? 9;
        final minGroup = match.group(3);

        if (text.contains('${match.group(2)}點半') || text.contains('${match.group(2)}:30')) {
          minute = 30;
        } else if (minGroup != null) {
          minute = int.tryParse(minGroup) ?? 0;
        }

        if (period == '下午' || period == '晚上') {
          if (parsedHour < 12) parsedHour += 12;
        } else if (period == '中午' && parsedHour < 11) {
          parsedHour += 12;
        }

        hour = parsedHour;
      }

      var date = now.add(Duration(days: dayOffset));
      targetTime = DateTime(date.year, date.month, date.day, hour, minute);

      // 若算出來的時間早於現在，自動順延至明天
      if (dayOffset == 0 && targetTime.isBefore(now)) {
        targetTime = targetTime.add(const Duration(days: 1));
      }
      timeDetected = true;
    }

    // 若完全未偵測到時間，預設為 1 小時後
    if (!timeDetected) {
      targetTime = now.add(const Duration(hours: 1));
    }

    // 5. 清理事項標題
    String cleanTitle = text
        .replaceAll(RegExp(r'^(提醒我|幫我記一下|記得要|記得|要|我想記|請提醒我)\s*'), '')
        .replaceAll(RegExp(r'(今天|明天|後天|大後天)'), '')
        .replaceAll(RegExp(r'(早上|上午|中午|下午|晚上)\s*\d{1,2}\s*(?:點|:|時)(?:\d{1,2}|半)?(?:分)?'), '')
        .replaceAll(RegExp(r'\d+\s*(?:個)?(?:分鐘|小時)後'), '')
        .replaceAll(RegExp(r'半小時後'), '')
        .replaceAll(RegExp(r'(的事情|的代辦|提醒|記得)'), '')
        .trim();

    if (cleanTitle.isEmpty) {
      cleanTitle = text;
    }

    // 6. 分類判斷
    String category = 'other';
    if (cleanTitle.contains('會') || cleanTitle.contains('工作') || cleanTitle.contains('報告') || cleanTitle.contains('專案')) {
      category = 'work';
    } else if (cleanTitle.contains('買') || cleanTitle.contains('繳費') || cleanTitle.contains('拿') || cleanTitle.contains('回家')) {
      category = 'life';
    } else if (cleanTitle.contains('吃藥') || cleanTitle.contains('看醫生') || cleanTitle.contains('診所') || cleanTitle.contains('運動')) {
      category = 'health';
    } else if (cleanTitle.contains('緊急') || cleanTitle.contains('立刻') || cleanTitle.contains('重要')) {
      category = 'urgent';
    }

    final timeDesc = DateFormat('M月d日 ah:mm', 'zh_TW').format(targetTime);
    final replyMessage = '好的！已為您設定 $timeDesc 提醒：$cleanTitle。';

    return AIParseResult(
      success: true,
      title: cleanTitle,
      targetTime: targetTime,
      category: category,
      replyMessage: replyMessage,
    );
  }
}
