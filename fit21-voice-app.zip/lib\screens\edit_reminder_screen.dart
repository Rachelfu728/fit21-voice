import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../models/reminder_item.dart';
import '../services/notification_service.dart';
import '../services/storage_service.dart';
import '../widgets/category_chip.dart';

class EditReminderScreen extends StatefulWidget {
  final ReminderItem? initialItem;

  const EditReminderScreen({super.key, this.initialItem});

  @override
  State<EditReminderScreen> createState() => _EditReminderScreenState();
}

class _EditReminderScreenState extends State<EditReminderScreen> {
  final _formKey = GlobalKey<FormState>();
  final _storageService = StorageService();
  final _notificationService = NotificationService();

  late TextEditingController _titleController;
  late TextEditingController _noteController;
  late DateTime _selectedDateTime;
  late String _selectedCategory;

  final List<String> _categories = ['work', 'life', 'urgent', 'health', 'other'];

  @override
  void initState() {
    super.initState();
    final item = widget.initialItem;
    _titleController = TextEditingController(text: item?.title ?? '');
    _noteController = TextEditingController(text: item?.note ?? '');
    _selectedDateTime = item?.reminderTime ?? DateTime.now().add(const Duration(hours: 1));
    _selectedCategory = item?.category ?? 'other';
  }

  @override
  void dispose() {
    _titleController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDateTime,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
    );
    if (picked != null) {
      setState(() {
        _selectedDateTime = DateTime(
          picked.year,
          picked.month,
          picked.day,
          _selectedDateTime.hour,
          _selectedDateTime.minute,
        );
      });
    }
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_selectedDateTime),
    );
    if (picked != null) {
      setState(() {
        _selectedDateTime = DateTime(
          _selectedDateTime.year,
          _selectedDateTime.month,
          _selectedDateTime.day,
          picked.hour,
          picked.minute,
        );
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final item = ReminderItem(
      id: widget.initialItem?.id ?? const Uuid().v4(),
      title: _titleController.text.trim(),
      reminderTime: _selectedDateTime,
      category: _selectedCategory,
      isCompleted: widget.initialItem?.isCompleted ?? false,
      rawVoiceInput: widget.initialItem?.rawVoiceInput ?? '',
      note: _noteController.text.trim().isEmpty ? null : _noteController.text.trim(),
    );

    await _storageService.saveReminder(item);

    // 重新排程通知
    if (!item.isCompleted && item.reminderTime.isAfter(DateTime.now())) {
      await _notificationService.scheduleReminder(item);
    } else {
      await _notificationService.cancelReminder(item);
    }

    if (mounted) {
      Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isEditing = widget.initialItem != null;

    final dateStr = DateFormat('yyyy/MM/dd (E)', 'zh_TW').format(_selectedDateTime);
    final timeStr = DateFormat('ah:mm', 'zh_TW').format(_selectedDateTime);

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? '編輯提醒' : '新增提醒'),
        actions: [
          IconButton(
            icon: const Icon(Icons.check),
            onPressed: _save,
            tooltip: '儲存',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 標題輸入
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: '提醒事項標題 *',
                  hintText: '例如：去郵局繳水電費',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.edit_note_rounded),
                ),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) {
                    return '請輸入事項標題';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),

              // 時間日期選擇
              Text('提醒時間', style: theme.textTheme.titleSmall),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickDate,
                      icon: const Icon(Icons.calendar_today_rounded, size: 18),
                      label: Text(dateStr),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickTime,
                      icon: const Icon(Icons.access_time_rounded, size: 18),
                      label: Text(timeStr),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // 分類選擇
              Text('分類標籤', style: theme.textTheme.titleSmall),
              const SizedBox(height: 10),
              Wrap(
                spacing: 10,
                runSpacing: 8,
                children: _categories.map((cat) {
                  return CategoryChip(
                    category: cat,
                    isSelected: _selectedCategory == cat,
                    onTap: () {
                      setState(() {
                        _selectedCategory = cat;
                      });
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),

              // 詳細備忘 (可選)
              TextFormField(
                controller: _noteController,
                maxLines: 3,
                decoration: InputDecoration(
                  labelText: '補充備忘 (選填)',
                  hintText: '可在此填寫相關電話、地址或備註內容...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  alignLabelWithHint: true,
                ),
              ),

              const SizedBox(height: 36),

              // 儲存按鈕
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.save_rounded),
                  label: const Text('儲存提醒事項', style: TextStyle(fontSize: 16)),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
